import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap";

export default function Header() {
  return (
    <nav className="navbar navbar-light bg-light">
      <div className="container-fluid">
        <a className="navbar-brand" href="https://source.unsplash.com/200x200">
          <img
            src="https://source.unsplash.com/400x400"
            alt=""
            width="30"
            height="24"
            className="d-inline-block align-text-top"
          />
        </a>
        <span className="h12">News and Events</span>
      </div>
    </nav>
  );
}
