import React from "react";
import "./style.css";

const Login = () => {
  const handleRegister = () => {
    alert("clicked");
  };
  return (
    <div className="container-fluid log">
      <div className="row">
        <div className="col">
          <div className="card text-dark bg-info mb-3">
            <div className="card-body">
              <center>
                <span className="sp">Login in</span>
              </center>
              <form>
                <div className="mb-3">
                  <label for="exampleInputEmail1" className="form-label">
                    Email address
                  </label>
                  <input
                    type="email"
                    className="form-control"
                    id="exampleInputEmail1"
                    aria-describedby="emailHelp"
                  />
                </div>
                <div className="mb-3">
                  <label for="exampleInputPassword1" className="form-label">
                    Password
                  </label>
                  <input
                    type="password"
                    className="form-control"
                    id="exampleInputPassword1"
                  />
                </div>
                <center>
                  <button type="submit" className="btn btn-primary">
                    Submit
                  </button>
                </center>
                <div style={{ marginLeft: 20 }}>
                  Not reistered?
                  <p className="but" onClick={handleRegister}>
                    click here!
                  </p>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
